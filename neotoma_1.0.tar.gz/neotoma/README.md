neotoma
========

This package is a programmatic R interface to the [Neotoma Paleoecological Database](http://www.neotomadb.org/). 

#### Neotoma API docs: [http://api.neotomadb.org/doc/](http://api.neotomadb.org/doc/)

#### Authors: [Simon Goring](simon.j.goring@gmail.com)

#### Quick start

```r

```